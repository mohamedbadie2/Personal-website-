import React, { useState } from 'react';
import { 
  AppBar, 
  Toolbar, 
  Typography, 
  Button, 
  IconButton, 
  Box, 
  Container,
  Menu,
  MenuItem,
  useMediaQuery
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import MenuIcon from '@mui/icons-material/Menu';
import Brightness4Icon from '@mui/icons-material/Brightness4';
import Brightness7Icon from '@mui/icons-material/Brightness7';
import { useTranslation } from 'react-i18next';
import { ColorModeContext } from './ThemeWrapper';

const Header = () => {
  const { t, i18n } = useTranslation();
  const theme = useTheme();
  const colorMode = React.useContext(ColorModeContext);
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  
  const handleMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };
  
  const handleClose = () => {
    setAnchorEl(null);
  };
  
  const changeLanguage = () => {
    i18n.changeLanguage(i18n.language === 'ar' ? 'en' : 'ar');
  };
  
  const menuItems = [
    { name: t('header.home'), path: '/' },
    { name: t('header.articles'), path: '/articles' },
    { name: t('header.books'), path: '/books' },
    { name: t('header.about'), path: '/about' },
    { name: t('header.contact'), path: '/contact' },
  ];
  
  return (
    <AppBar position="static" color="transparent" elevation={0} sx={{ borderBottom: 1, borderColor: 'divider' }}>
      <Container maxWidth="lg">
        <Toolbar disableGutters>
          <Typography
            variant="h6"
            noWrap
            component="div"
            sx={{ 
              flexGrow: 1, 
              fontWeight: 'bold',
              fontFamily: theme.direction === 'rtl' 
                ? '"IBM Plex Sans Arabic", sans-serif' 
                : '"Playfair Display", serif'
            }}
          >
            محمد عبدالبديع | تأملات
          </Typography>
          
          {isMobile ? (
            <Box>
              <IconButton
                size="large"
                edge="end"
                color="inherit"
                aria-label="menu"
                onClick={handleMenu}
              >
                <MenuIcon />
              </IconButton>
              <Menu
                id="menu-appbar"
                anchorEl={anchorEl}
                anchorOrigin={{
                  vertical: 'top',
                  horizontal: theme.direction === 'rtl' ? 'left' : 'right',
                }}
                keepMounted
                transformOrigin={{
                  vertical: 'top',
                  horizontal: theme.direction === 'rtl' ? 'left' : 'right',
                }}
                open={open}
                onClose={handleClose}
              >
                {menuItems.map((item) => (
                  <MenuItem key={item.path} onClick={handleClose}>
                    {item.name}
                  </MenuItem>
                ))}
                <MenuItem onClick={changeLanguage}>
                  {t('header.language')}
                </MenuItem>
                <MenuItem onClick={colorMode.toggleColorMode}>
                  {theme.palette.mode === 'dark' ? t('theme.light') : t('theme.dark')}
                </MenuItem>
              </Menu>
            </Box>
          ) : (
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              {menuItems.map((item) => (
                <Button
                  key={item.path}
                  color="inherit"
                  sx={{ mx: 1 }}
                >
                  {item.name}
                </Button>
              ))}
              <IconButton sx={{ ml: 1 }} onClick={colorMode.toggleColorMode} color="inherit">
                {theme.palette.mode === 'dark' ? <Brightness7Icon /> : <Brightness4Icon />}
              </IconButton>
              <Button color="inherit" onClick={changeLanguage} sx={{ ml: 1 }}>
                {t('header.language')}
              </Button>
            </Box>
          )}
        </Toolbar>
      </Container>
    </AppBar>
  );
};

export default Header;

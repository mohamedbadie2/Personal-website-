import React, { useState } from 'react';
import { 
  Box, 
  Container, 
  Typography, 
  Grid, 
  Card, 
  CardContent, 
  TextField, 
  InputAdornment,
  ToggleButtonGroup,
  ToggleButton,
  Chip,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  useTheme
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import ViewListIcon from '@mui/icons-material/ViewList';
import ViewModuleIcon from '@mui/icons-material/ViewModule';
import { useTranslation } from 'react-i18next';

const ArticlesPage = () => {
  const { t } = useTranslation();
  const theme = useTheme();
  const [viewMode, setViewMode] = useState('grid');
  const [category, setCategory] = useState('all');
  
  const handleViewChange = (event, newView) => {
    if (newView !== null) {
      setViewMode(newView);
    }
  };
  
  const handleCategoryChange = (event) => {
    setCategory(event.target.value);
  };
  
  // محتوى تجريبي للمقالات
  const articles = [
    {
      id: 1,
      title: 'لماذا نفشل في بناء المعنى رغم وضوح الأهداف؟',
      excerpt: 'نتحدث كثيراً عن أهمية وضوح الأهداف، لكن ماذا لو كانت المشكلة أعمق من ذلك؟ في هذا المقال نتأمل في العلاقة بين الأهداف والمعنى وكيف يمكن أن نجد توازناً بينهما في حياتنا الشخصية والمهنية.',
      image: 'https://source.unsplash.com/random/300x200?philosophy',
      date: '15 مايو 2025',
      category: 'تأملات'
    },
    {
      id: 2,
      title: 'تأملات في فن التأسيس: من يسبق من، الخطة أم القيم؟',
      excerpt: 'عندما نبدأ مشروعاً جديداً، هل نبدأ بوضع خطة تفصيلية أم بتحديد القيم التي ستوجه مسارنا؟ في هذا المقال نستكشف العلاقة بين الخطط والقيم وكيف يمكن أن تتكامل لبناء أساس متين لأي مشروع.',
      image: 'https://source.unsplash.com/random/300x200?planning',
      date: '10 مايو 2025',
      category: 'ريادة أعمال'
    },
    {
      id: 3,
      title: 'دفاتر مقاول في سوقٍ بلا هوية',
      excerpt: 'تجربة شخصية في بناء مشروع تجاري في سوق يفتقر إلى الهوية الواضحة. كيف يمكن للمقاول أن يحدد هويته وسط هذا الغموض؟ وما هي التحديات التي يواجهها في بناء علامة تجارية مميزة؟',
      image: 'https://source.unsplash.com/random/300x200?business',
      date: '5 مايو 2025',
      category: 'ريادة أعمال'
    },
    {
      id: 4,
      title: 'من دفتر التأسيس إلى يوميات التشغيل: رسائل لقائد ناشئ',
      excerpt: 'سلسلة من الرسائل الموجهة للقادة الجدد في عالم الأعمال، تتناول التحديات التي يواجهونها في الانتقال من مرحلة التأسيس إلى مرحلة التشغيل، وكيفية التعامل معها بحكمة وفعالية.',
      image: 'https://source.unsplash.com/random/300x200?leadership',
      date: '1 مايو 2025',
      category: 'قيادة'
    },
    {
      id: 5,
      title: 'الفرق بين القائد والمدير: تأملات في جوهر القيادة',
      excerpt: 'هل كل مدير قائد؟ وهل كل قائد بالضرورة مدير؟ في هذا المقال نتأمل في الفروق الجوهرية بين القيادة والإدارة، ونستكشف كيف يمكن للشخص أن يجمع بين المهارتين لتحقيق نتائج استثنائية.',
      image: 'https://source.unsplash.com/random/300x200?management',
      date: '25 أبريل 2025',
      category: 'قيادة'
    },
    {
      id: 6,
      title: 'كيف تبني ثقافة التعلم المستمر في مؤسستك؟',
      excerpt: 'في عصر التغير السريع، أصبح التعلم المستمر ضرورة وليس ترفاً. كيف يمكن للقادة بناء ثقافة تشجع على التعلم المستمر والتطوير الذاتي؟ وما هي الممارسات العملية التي يمكن تطبيقها لتحقيق ذلك؟',
      image: 'https://source.unsplash.com/random/300x200?learning',
      date: '20 أبريل 2025',
      category: 'تطوير ذاتي'
    }
  ];
  
  // تصفية المقالات حسب الفئة
  const filteredArticles = category === 'all' 
    ? articles 
    : articles.filter(article => article.category === category);
  
  // الفئات المتاحة
  const categories = ['all', ...new Set(articles.map(article => article.category))];
  
  return (
    <Box sx={{ flexGrow: 1, py: 4 }}>
      <Container maxWidth="lg">
        <Typography 
          variant="h3" 
          component="h1" 
          gutterBottom
          sx={{ 
            mb: 4,
            position: 'relative',
            '&:after': {
              content: '""',
              position: 'absolute',
              bottom: -10,
              left: theme.direction === 'rtl' ? 0 : 'auto',
              right: theme.direction === 'rtl' ? 'auto' : 0,
              width: '80px',
              height: '3px',
              backgroundColor: theme.palette.primary.main
            }
          }}
        >
          {t('articles.title')}
        </Typography>
        
        {/* أدوات البحث والتصفية */}
        <Box sx={{ mb: 4, display: 'flex', flexDirection: { xs: 'column', md: 'row' }, gap: 2, alignItems: { xs: 'stretch', md: 'center' } }}>
          <TextField
            placeholder={t('articles.search')}
            variant="outlined"
            size="small"
            fullWidth
            sx={{ maxWidth: { xs: '100%', md: '300px' } }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon />
                </InputAdornment>
              ),
            }}
          />
          
          <FormControl size="small" sx={{ minWidth: 150 }}>
            <InputLabel id="category-select-label">{t('articles.filter')}</InputLabel>
            <Select
              labelId="category-select-label"
              id="category-select"
              value={category}
              label={t('articles.filter')}
              onChange={handleCategoryChange}
            >
              {categories.map((cat) => (
                <MenuItem key={cat} value={cat}>
                  {cat === 'all' ? 'الكل' : cat}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          
          <Box sx={{ flexGrow: 1 }} />
          
          <ToggleButtonGroup
            value={viewMode}
            exclusive
            onChange={handleViewChange}
            aria-label="view mode"
            size="small"
          >
            <ToggleButton value="grid" aria-label="grid view">
              <ViewModuleIcon />
            </ToggleButton>
            <ToggleButton value="list" aria-label="list view">
              <ViewListIcon />
            </ToggleButton>
          </ToggleButtonGroup>
        </Box>
        
        {/* عرض المقالات */}
        <Grid container spacing={4}>
          {filteredArticles.map((article) => (
            <Grid item xs={12} md={viewMode === 'grid' ? 4 : 12} key={article.id}>
              <Card 
                sx={{ 
                  height: '100%', 
                  display: 'flex', 
                  flexDirection: viewMode === 'grid' ? 'column' : { xs: 'column', sm: 'row' },
                  transition: 'transform 0.3s ease',
                  '&:hover': {
                    transform: 'translateY(-5px)'
                  }
                }}
              >
                <Box
                  sx={{
                    width: viewMode === 'grid' ? '100%' : { xs: '100%', sm: '200px' },
                    height: viewMode === 'grid' ? '200px' : { xs: '200px', sm: 'auto' },
                    backgroundImage: `url(${article.image})`,
                    backgroundSize: 'cover',
                    backgroundPosition: 'center',
                  }}
                />
                <Box sx={{ display: 'flex', flexDirection: 'column', flexGrow: 1 }}>
                  <CardContent sx={{ flexGrow: 1 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 1 }}>
                      <Typography gutterBottom variant="h6" component="h2">
                        {article.title}
                      </Typography>
                      <Chip 
                        label={article.category} 
                        size="small" 
                        color="primary" 
                        variant="outlined"
                        sx={{ ml: 1 }}
                      />
                    </Box>
                    <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                      {article.date}
                    </Typography>
                    <Typography variant="body2">
                      {article.excerpt}
                    </Typography>
                  </CardContent>
                </Box>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>
    </Box>
  );
};

export default ArticlesPage;

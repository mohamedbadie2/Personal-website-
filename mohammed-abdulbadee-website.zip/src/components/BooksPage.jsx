import React from 'react';
import { 
  Box, 
  Container, 
  Typography, 
  Grid, 
  Card, 
  CardContent, 
  CardMedia, 
  Button,
  Divider,
  Paper,
  useTheme
} from '@mui/material';
import { useTranslation } from 'react-i18next';

const BooksPage = () => {
  const { t } = useTranslation();
  const theme = useTheme();
  
  // محتوى تجريبي للكتب
  const books = [
    {
      id: 1,
      title: 'كيف تبني شركتك بعقل خبير وقلب قائد',
      cover: 'https://source.unsplash.com/random/400x600?book',
      description: 'دليل عملي للمؤسسين الجدد يجمع بين الخبرة التقنية ومهارات القيادة. يتناول الكتاب التحديات التي يواجهها رواد الأعمال في بداية مشوارهم، ويقدم نصائح عملية مستوحاة من تجارب حقيقية.',
      publishDate: '2024',
      pages: 320,
      categories: ['ريادة أعمال', 'قيادة', 'إدارة']
    },
    {
      id: 2,
      title: 'من دفتر التأسيس إلى يوميات التشغيل: رسائل لقائد ناشئ',
      cover: 'https://source.unsplash.com/random/400x600?notebook',
      description: 'مجموعة من الرسائل والتأملات حول رحلة بناء المشاريع من الفكرة إلى التشغيل. يشارك الكاتب تجاربه الشخصية والدروس المستفادة من النجاحات والإخفاقات على حد سواء.',
      publishDate: '2023',
      pages: 280,
      categories: ['ريادة أعمال', 'تطوير ذاتي', 'إدارة']
    },
    {
      id: 3,
      title: 'تأملات في فن القيادة: كيف تلهم الآخرين وتقودهم نحو النجاح',
      cover: 'https://source.unsplash.com/random/400x600?leadership',
      description: 'يستكشف هذا الكتاب جوهر القيادة الحقيقية ويقدم رؤى عميقة حول كيفية إلهام الآخرين وتحفيزهم لتحقيق إمكاناتهم الكاملة. من خلال قصص واقعية وتمارين عملية، يساعد القراء على تطوير مهاراتهم القيادية.',
      publishDate: '2022',
      pages: 250,
      categories: ['قيادة', 'تطوير ذاتي', 'علم النفس']
    }
  ];
  
  return (
    <Box sx={{ flexGrow: 1, py: 4 }}>
      <Container maxWidth="lg">
        <Typography 
          variant="h3" 
          component="h1" 
          gutterBottom
          sx={{ 
            mb: 4,
            position: 'relative',
            '&:after': {
              content: '""',
              position: 'absolute',
              bottom: -10,
              left: theme.direction === 'rtl' ? 0 : 'auto',
              right: theme.direction === 'rtl' ? 'auto' : 0,
              width: '80px',
              height: '3px',
              backgroundColor: theme.palette.primary.main
            }
          }}
        >
          {t('books.title')}
        </Typography>
        
        {/* عرض الكتب */}
        <Grid container spacing={6}>
          {books.map((book) => (
            <Grid item xs={12} key={book.id}>
              <Paper 
                elevation={2} 
                sx={{ 
                  p: 3, 
                  borderRadius: 2,
                  transition: 'transform 0.3s ease',
                  '&:hover': {
                    transform: 'translateY(-5px)'
                  }
                }}
              >
                <Grid container spacing={3}>
                  <Grid item xs={12} sm={4} md={3}>
                    <CardMedia
                      component="img"
                      image={book.cover}
                      alt={book.title}
                      sx={{ 
                        width: '100%', 
                        borderRadius: 1,
                        boxShadow: '0 4px 8px rgba(0,0,0,0.1)'
                      }}
                    />
                  </Grid>
                  <Grid item xs={12} sm={8} md={9}>
                    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
                      <Typography variant="h4" component="h2" gutterBottom>
                        {book.title}
                      </Typography>
                      
                      <Box sx={{ mb: 2, display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                        {book.categories.map((category, index) => (
                          <Typography 
                            key={index} 
                            variant="body2" 
                            component="span"
                            sx={{ 
                              color: theme.palette.primary.main,
                              backgroundColor: theme.palette.mode === 'dark' ? 'rgba(26, 54, 93, 0.1)' : 'rgba(26, 54, 93, 0.05)',
                              px: 1.5,
                              py: 0.5,
                              borderRadius: 5,
                              fontSize: '0.8rem'
                            }}
                          >
                            {category}
                          </Typography>
                        ))}
                      </Box>
                      
                      <Box sx={{ mb: 2, display: 'flex', gap: 3 }}>
                        <Typography variant="body2" color="text.secondary">
                          <strong>تاريخ النشر:</strong> {book.publishDate}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          <strong>عدد الصفحات:</strong> {book.pages}
                        </Typography>
                      </Box>
                      
                      <Typography variant="body1" paragraph sx={{ mb: 3 }}>
                        {book.description}
                      </Typography>
                      
                      <Box sx={{ mt: 'auto', display: 'flex', gap: 2 }}>
                        <Button 
                          variant="contained" 
                          color="primary"
                          sx={{ 
                            px: 3,
                            borderRadius: 2
                          }}
                        >
                          {t('books.read')}
                        </Button>
                        <Button 
                          variant="outlined" 
                          color="primary"
                          sx={{ 
                            px: 3,
                            borderRadius: 2
                          }}
                        >
                          {t('books.download')}
                        </Button>
                      </Box>
                    </Box>
                  </Grid>
                </Grid>
              </Paper>
            </Grid>
          ))}
        </Grid>
      </Container>
    </Box>
  );
};

export default BooksPage;

import React, { useState } from 'react';
import { 
  Box, 
  Container, 
  Typography, 
  Grid, 
  Paper,
  TextField,
  Button,
  Divider,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Snackbar,
  Alert,
  useTheme
} from '@mui/material';
import EmailIcon from '@mui/icons-material/Email';
import PhoneIcon from '@mui/icons-material/Phone';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import TwitterIcon from '@mui/icons-material/Twitter';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import { useTranslation } from 'react-i18next';

const ContactPage = () => {
  const { t } = useTranslation();
  const theme = useTheme();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success'
  });
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    // هنا يمكن إضافة منطق إرسال النموذج إلى الخادم
    console.log('Form submitted:', formData);
    
    // عرض رسالة نجاح
    setSnackbar({
      open: true,
      message: 'تم إرسال رسالتك بنجاح. سنتواصل معك قريباً.',
      severity: 'success'
    });
    
    // إعادة تعيين النموذج
    setFormData({
      name: '',
      email: '',
      message: ''
    });
  };
  
  const handleCloseSnackbar = () => {
    setSnackbar(prev => ({
      ...prev,
      open: false
    }));
  };
  
  return (
    <Box sx={{ flexGrow: 1, py: 4 }}>
      <Container maxWidth="lg">
        <Typography 
          variant="h3" 
          component="h1" 
          gutterBottom
          sx={{ 
            mb: 4,
            position: 'relative',
            '&:after': {
              content: '""',
              position: 'absolute',
              bottom: -10,
              left: theme.direction === 'rtl' ? 0 : 'auto',
              right: theme.direction === 'rtl' ? 'auto' : 0,
              width: '80px',
              height: '3px',
              backgroundColor: theme.palette.primary.main
            }
          }}
        >
          {t('contact.title')}
        </Typography>
        
        <Grid container spacing={4}>
          {/* نموذج التواصل */}
          <Grid item xs={12} md={7}>
            <Paper 
              elevation={2} 
              sx={{ 
                p: 3, 
                borderRadius: 2
              }}
            >
              <Typography variant="h5" component="h2" gutterBottom>
                أرسل رسالة
              </Typography>
              <Typography variant="body1" paragraph color="text.secondary">
                يسعدني التواصل معك والإجابة على استفساراتك. يرجى ملء النموذج أدناه وسأرد عليك في أقرب وقت ممكن.
              </Typography>
              
              <Box component="form" onSubmit={handleSubmit} sx={{ mt: 3 }}>
                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <TextField
                      required
                      fullWidth
                      id="name"
                      label={t('contact.name')}
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      variant="outlined"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      required
                      fullWidth
                      id="email"
                      label={t('contact.email')}
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleChange}
                      variant="outlined"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      required
                      fullWidth
                      id="message"
                      label={t('contact.message')}
                      name="message"
                      multiline
                      rows={6}
                      value={formData.message}
                      onChange={handleChange}
                      variant="outlined"
                    />
                  </Grid>
                </Grid>
                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  size="large"
                  sx={{ mt: 3, mb: 2, px: 4, borderRadius: 2 }}
                >
                  {t('contact.send')}
                </Button>
              </Box>
            </Paper>
          </Grid>
          
          {/* معلومات التواصل المباشر */}
          <Grid item xs={12} md={5}>
            <Paper 
              elevation={2} 
              sx={{ 
                p: 3, 
                height: '100%',
                borderRadius: 2
              }}
            >
              <Typography variant="h5" component="h2" gutterBottom>
                {t('contact.direct_contact')}
              </Typography>
              <Typography variant="body1" paragraph color="text.secondary">
                يمكنك أيضاً التواصل معي مباشرة من خلال وسائل الاتصال التالية:
              </Typography>
              
              <List sx={{ mt: 2 }}>
                <ListItem disableGutters>
                  <ListItemIcon>
                    <EmailIcon color="primary" />
                  </ListItemIcon>
                  <ListItemText 
                    primary="البريد الإلكتروني" 
                    secondary="contact@mohammedabdulbadee.com" 
                  />
                </ListItem>
                <ListItem disableGutters>
                  <ListItemIcon>
                    <PhoneIcon color="primary" />
                  </ListItemIcon>
                  <ListItemText 
                    primary="الهاتف" 
                    secondary="+966 50 123 4567" 
                  />
                </ListItem>
                <ListItem disableGutters>
                  <ListItemIcon>
                    <LocationOnIcon color="primary" />
                  </ListItemIcon>
                  <ListItemText 
                    primary="العنوان" 
                    secondary="الرياض، المملكة العربية السعودية" 
                  />
                </ListItem>
              </List>
              
              <Divider sx={{ my: 3 }} />
              
              <Typography variant="h6" component="h3" gutterBottom>
                تابعني على وسائل التواصل الاجتماعي
              </Typography>
              
              <Box sx={{ display: 'flex', gap: 2, mt: 2 }}>
                <Button 
                  variant="outlined" 
                  color="primary" 
                  startIcon={<TwitterIcon />}
                  sx={{ borderRadius: 2 }}
                >
                  Twitter
                </Button>
                <Button 
                  variant="outlined" 
                  color="primary" 
                  startIcon={<LinkedInIcon />}
                  sx={{ borderRadius: 2 }}
                >
                  LinkedIn
                </Button>
              </Box>
            </Paper>
          </Grid>
        </Grid>
      </Container>
      
      {/* رسالة النجاح */}
      <Snackbar 
        open={snackbar.open} 
        autoHideDuration={6000} 
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert 
          onClose={handleCloseSnackbar} 
          severity={snackbar.severity} 
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default ContactPage;

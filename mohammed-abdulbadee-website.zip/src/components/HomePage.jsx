import React from 'react';
import { 
  Box, 
  Container, 
  Typography, 
  Grid, 
  Card, 
  CardContent, 
  CardMedia, 
  Button,
  Paper,
  useTheme
} from '@mui/material';
import { useTranslation } from 'react-i18next';

const HomePage = () => {
  const { t } = useTranslation();
  const theme = useTheme();
  
  // محتوى تجريبي للمقالات
  const articles = [
    {
      id: 1,
      title: 'لماذا نفشل في بناء المعنى رغم وضوح الأهداف؟',
      excerpt: 'نتحدث كثيراً عن أهمية وضوح الأهداف، لكن ماذا لو كانت المشكلة أعمق من ذلك؟ في هذا المقال نتأمل في العلاقة بين الأهداف والمعنى...',
      image: 'https://source.unsplash.com/random/300x200?philosophy',
      date: '15 مايو 2025'
    },
    {
      id: 2,
      title: 'تأملات في فن التأسيس: من يسبق من، الخطة أم القيم؟',
      excerpt: 'عندما نبدأ مشروعاً جديداً، هل نبدأ بوضع خطة تفصيلية أم بتحديد القيم التي ستوجه مسارنا؟ في هذا المقال نستكشف العلاقة بين الخطط والقيم...',
      image: 'https://source.unsplash.com/random/300x200?planning',
      date: '10 مايو 2025'
    },
    {
      id: 3,
      title: 'دفاتر مقاول في سوقٍ بلا هوية',
      excerpt: 'تجربة شخصية في بناء مشروع تجاري في سوق يفتقر إلى الهوية الواضحة. كيف يمكن للمقاول أن يحدد هويته وسط هذا الغموض؟',
      image: 'https://source.unsplash.com/random/300x200?business',
      date: '5 مايو 2025'
    }
  ];
  
  // محتوى تجريبي للكتب
  const books = [
    {
      id: 1,
      title: 'كيف تبني شركتك بعقل خبير وقلب قائد',
      cover: 'https://source.unsplash.com/random/200x300?book',
      description: 'دليل عملي للمؤسسين الجدد يجمع بين الخبرة التقنية ومهارات القيادة'
    },
    {
      id: 2,
      title: 'من دفتر التأسيس إلى يوميات التشغيل: رسائل لقائد ناشئ',
      cover: 'https://source.unsplash.com/random/200x300?notebook',
      description: 'مجموعة من الرسائل والتأملات حول رحلة بناء المشاريع من الفكرة إلى التشغيل'
    }
  ];
  
  return (
    <Box sx={{ flexGrow: 1, py: 4 }}>
      {/* قسم الترحيب */}
      <Container maxWidth="lg">
        <Paper 
          elevation={0} 
          sx={{ 
            p: 6, 
            mb: 6, 
            textAlign: 'center',
            backgroundColor: theme.palette.mode === 'dark' ? 'rgba(30, 30, 30, 0.8)' : 'rgba(245, 245, 245, 0.8)',
            borderRadius: 2
          }}
        >
          <Typography 
            variant="h3" 
            component="h1" 
            gutterBottom
            sx={{ 
              fontWeight: 'bold',
              mb: 3
            }}
          >
            {t('home.welcome')}
          </Typography>
          <Typography 
            variant="h5" 
            component="p"
            sx={{ 
              fontStyle: 'italic',
              color: theme.palette.text.secondary,
              maxWidth: '800px',
              mx: 'auto',
              lineHeight: 1.8
            }}
          >
            {t('home.quote')}
          </Typography>
        </Paper>
        
        {/* قسم أحدث المقالات */}
        <Box sx={{ mb: 8 }}>
          <Typography 
            variant="h4" 
            component="h2" 
            gutterBottom
            sx={{ 
              mb: 4,
              position: 'relative',
              '&:after': {
                content: '""',
                position: 'absolute',
                bottom: -10,
                left: theme.direction === 'rtl' ? 0 : 'auto',
                right: theme.direction === 'rtl' ? 'auto' : 0,
                width: '80px',
                height: '3px',
                backgroundColor: theme.palette.primary.main
              }
            }}
          >
            {t('home.latest_articles')}
          </Typography>
          
          <Grid container spacing={4}>
            {articles.map((article) => (
              <Grid item xs={12} md={4} key={article.id}>
                <Card 
                  sx={{ 
                    height: '100%', 
                    display: 'flex', 
                    flexDirection: 'column',
                    transition: 'transform 0.3s ease',
                    '&:hover': {
                      transform: 'translateY(-5px)'
                    }
                  }}
                >
                  <CardMedia
                    component="img"
                    height="200"
                    image={article.image}
                    alt={article.title}
                  />
                  <CardContent sx={{ flexGrow: 1 }}>
                    <Typography gutterBottom variant="h6" component="h3">
                      {article.title}
                    </Typography>
                    <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                      {article.date}
                    </Typography>
                    <Typography variant="body2">
                      {article.excerpt}
                    </Typography>
                  </CardContent>
                  <Box sx={{ p: 2, pt: 0 }}>
                    <Button size="small" color="primary">
                      {t('home.read_more')}
                    </Button>
                  </Box>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Box>
        
        {/* قسم الكتب المميزة */}
        <Box>
          <Typography 
            variant="h4" 
            component="h2" 
            gutterBottom
            sx={{ 
              mb: 4,
              position: 'relative',
              '&:after': {
                content: '""',
                position: 'absolute',
                bottom: -10,
                left: theme.direction === 'rtl' ? 0 : 'auto',
                right: theme.direction === 'rtl' ? 'auto' : 0,
                width: '80px',
                height: '3px',
                backgroundColor: theme.palette.primary.main
              }
            }}
          >
            {t('home.featured_books')}
          </Typography>
          
          <Grid container spacing={4}>
            {books.map((book) => (
              <Grid item xs={12} sm={6} key={book.id}>
                <Card 
                  sx={{ 
                    display: 'flex', 
                    height: '100%',
                    transition: 'transform 0.3s ease',
                    '&:hover': {
                      transform: 'translateY(-5px)'
                    }
                  }}
                >
                  <CardMedia
                    component="img"
                    sx={{ width: 150 }}
                    image={book.cover}
                    alt={book.title}
                  />
                  <Box sx={{ display: 'flex', flexDirection: 'column', flexGrow: 1 }}>
                    <CardContent sx={{ flexGrow: 1 }}>
                      <Typography component="h3" variant="h6">
                        {book.title}
                      </Typography>
                      <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                        {book.description}
                      </Typography>
                    </CardContent>
                    <Box sx={{ display: 'flex', p: 2, pt: 0 }}>
                      <Button size="small" color="primary" sx={{ mr: 1 }}>
                        {t('books.read')}
                      </Button>
                      <Button size="small" color="secondary">
                        {t('books.download')}
                      </Button>
                    </Box>
                  </Box>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Box>
      </Container>
    </Box>
  );
};

export default HomePage;

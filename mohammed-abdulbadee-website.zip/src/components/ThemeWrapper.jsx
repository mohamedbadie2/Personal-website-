import React, { useState, createContext, useMemo } from 'react';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { CssBaseline } from '@mui/material';
import { useTranslation } from 'react-i18next';
import rtlPlugin from 'stylis-plugin-rtl';
import { prefixer } from 'stylis';
import { CacheProvider } from '@emotion/react';
import createCache from '@emotion/cache';

// إنشاء سياق للثيم
export const ColorModeContext = createContext({
  toggleColorMode: () => {},
  mode: 'light',
});

// إنشاء مكون الثيم
export default function ThemeWrapper({ children }) {
  const { i18n } = useTranslation();
  const [mode, setMode] = useState('light');
  const isRtl = i18n.language === 'ar';

  // إنشاء كاش للاتجاه
  const cacheRtl = createCache({
    key: 'muirtl',
    stylisPlugins: isRtl ? [prefixer, rtlPlugin] : [prefixer],
  });

  // تبديل وضع الألوان
  const colorMode = useMemo(
    () => ({
      toggleColorMode: () => {
        setMode((prevMode) => (prevMode === 'light' ? 'dark' : 'light'));
      },
      mode,
    }),
    [mode]
  );

  // إنشاء الثيم
  const theme = useMemo(
    () =>
      createTheme({
        direction: isRtl ? 'rtl' : 'ltr',
        palette: {
          mode,
          primary: {
            main: '#1A365D', // أزرق ليلي
          },
          secondary: {
            main: '#D6CFC7', // بيج
          },
          background: {
            default: mode === 'light' ? '#FFFFFF' : '#121212',
            paper: mode === 'light' ? '#F5F5F5' : '#1E1E1E',
          },
          text: {
            primary: mode === 'light' ? '#2B2B2B' : '#E0E0E0',
            secondary: mode === 'light' ? '#4A4A4A' : '#A0A0A0',
          },
        },
        typography: {
          fontFamily: isRtl
            ? '"IBM Plex Sans Arabic", "Noto Naskh Arabic", sans-serif'
            : '"Playfair Display", "Merriweather", "Montserrat", sans-serif',
          h1: {
            fontFamily: isRtl
              ? '"IBM Plex Sans Arabic", sans-serif'
              : '"Playfair Display", serif',
            fontWeight: 700,
          },
          h2: {
            fontFamily: isRtl
              ? '"IBM Plex Sans Arabic", sans-serif'
              : '"Playfair Display", serif',
            fontWeight: 600,
          },
          h3: {
            fontFamily: isRtl
              ? '"IBM Plex Sans Arabic", sans-serif'
              : '"Playfair Display", serif',
            fontWeight: 600,
          },
          h4: {
            fontFamily: isRtl
              ? '"IBM Plex Sans Arabic", sans-serif'
              : '"Playfair Display", serif',
            fontWeight: 500,
          },
          h5: {
            fontFamily: isRtl
              ? '"IBM Plex Sans Arabic", sans-serif'
              : '"Playfair Display", serif',
            fontWeight: 500,
          },
          h6: {
            fontFamily: isRtl
              ? '"IBM Plex Sans Arabic", sans-serif'
              : '"Playfair Display", serif',
            fontWeight: 500,
          },
          body1: {
            fontFamily: isRtl
              ? '"Noto Naskh Arabic", sans-serif'
              : '"Merriweather", serif',
            lineHeight: 1.6,
          },
          body2: {
            fontFamily: isRtl
              ? '"Noto Naskh Arabic", sans-serif'
              : '"Merriweather", serif',
            lineHeight: 1.6,
          },
          button: {
            fontFamily: isRtl
              ? '"IBM Plex Sans Arabic", sans-serif'
              : '"Montserrat", sans-serif',
            fontWeight: 500,
          },
        },
        components: {
          MuiCssBaseline: {
            styleOverrides: {
              body: {
                transition: 'all 0.3s ease',
              },
            },
          },
        },
      }),
    [mode, isRtl]
  );

  return (
    <ColorModeContext.Provider value={colorMode}>
      <CacheProvider value={cacheRtl}>
        <ThemeProvider theme={theme}>
          <CssBaseline />
          {children}
        </ThemeProvider>
      </CacheProvider>
    </ColorModeContext.Provider>
  );
}

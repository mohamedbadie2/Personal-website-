import React from 'react';
import { 
  Box, 
  Container, 
  Typography, 
  Grid, 
  Paper,
  Avatar,
  Divider,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  useTheme
} from '@mui/material';
import PersonIcon from '@mui/icons-material/Person';
import TimelineIcon from '@mui/icons-material/Timeline';
import VisibilityIcon from '@mui/icons-material/Visibility';
import InterestsIcon from '@mui/icons-material/Interests';
import { useTranslation } from 'react-i18next';

const AboutPage = () => {
  const { t } = useTranslation();
  const theme = useTheme();
  
  return (
    <Box sx={{ flexGrow: 1, py: 4 }}>
      <Container maxWidth="lg">
        <Typography 
          variant="h3" 
          component="h1" 
          gutterBottom
          sx={{ 
            mb: 4,
            position: 'relative',
            '&:after': {
              content: '""',
              position: 'absolute',
              bottom: -10,
              left: theme.direction === 'rtl' ? 0 : 'auto',
              right: theme.direction === 'rtl' ? 'auto' : 0,
              width: '80px',
              height: '3px',
              backgroundColor: theme.palette.primary.main
            }
          }}
        >
          {t('about.title')}
        </Typography>
        
        <Grid container spacing={4}>
          {/* صورة الكاتب والمقدمة */}
          <Grid item xs={12}>
            <Paper 
              elevation={0} 
              sx={{ 
                p: 4, 
                display: 'flex', 
                flexDirection: { xs: 'column', md: 'row' },
                alignItems: 'center',
                gap: 4,
                backgroundColor: theme.palette.mode === 'dark' ? 'rgba(30, 30, 30, 0.8)' : 'rgba(245, 245, 245, 0.8)',
                borderRadius: 2
              }}
            >
              <Avatar 
                src="https://source.unsplash.com/random/400x400?portrait" 
                alt="محمد عبدالبديع"
                sx={{ 
                  width: { xs: 150, md: 200 }, 
                  height: { xs: 150, md: 200 },
                  boxShadow: '0 4px 8px rgba(0,0,0,0.1)'
                }}
              />
              <Box>
                <Typography variant="h4" component="h2" gutterBottom>
                  محمد عبدالبديع
                </Typography>
                <Typography variant="body1" paragraph>
                  كاتب ومفكر متخصص في مجالات القيادة وريادة الأعمال والتطوير الذاتي. أسعى من خلال كتاباتي إلى تقديم رؤى عميقة ومتأملة حول تحديات الحياة المعاصرة، مستنداً إلى تجاربي الشخصية وخبراتي المهنية المتنوعة.
                </Typography>
                <Typography variant="body1">
                  أؤمن بأن الكتابة هي وسيلة للتأمل والاستكشاف، وأسعى من خلالها إلى مساعدة القراء على فهم أنفسهم وعالمهم بشكل أعمق، وتطوير قدراتهم على مواجهة التحديات وبناء حياة ذات معنى.
                </Typography>
              </Box>
            </Paper>
          </Grid>
          
          {/* السيرة الذاتية */}
          <Grid item xs={12} md={6}>
            <Paper 
              elevation={2} 
              sx={{ 
                p: 3, 
                height: '100%',
                borderRadius: 2
              }}
            >
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <PersonIcon color="primary" sx={{ mr: 1 }} />
                <Typography variant="h5" component="h3">
                  {t('about.bio')}
                </Typography>
              </Box>
              <Divider sx={{ mb: 2 }} />
              <Typography variant="body1" paragraph>
                حاصل على درجة الماجستير في إدارة الأعمال من جامعة مرموقة، مع خبرة تزيد عن 15 عاماً في مجالات الإدارة والاستشارات وريادة الأعمال.
              </Typography>
              <Typography variant="body1" paragraph>
                عملت في العديد من الشركات الكبرى، وأسست عدة مشاريع ناجحة في مجالات مختلفة. كما قدمت استشارات لمئات الشركات الناشئة والمؤسسات الصغيرة والمتوسطة.
              </Typography>
              <Typography variant="body1">
                أشارك بانتظام في المؤتمرات والندوات المحلية والدولية، وأقدم ورش عمل في مجالات القيادة والإدارة وريادة الأعمال.
              </Typography>
            </Paper>
          </Grid>
          
          {/* الرحلة الفكرية */}
          <Grid item xs={12} md={6}>
            <Paper 
              elevation={2} 
              sx={{ 
                p: 3, 
                height: '100%',
                borderRadius: 2
              }}
            >
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <TimelineIcon color="primary" sx={{ mr: 1 }} />
                <Typography variant="h5" component="h3">
                  {t('about.journey')}
                </Typography>
              </Box>
              <Divider sx={{ mb: 2 }} />
              <Typography variant="body1" paragraph>
                بدأت رحلتي الفكرية منذ سنوات الدراسة الأولى، حيث كنت شغوفاً بالقراءة والكتابة والتأمل في قضايا الإنسان والمجتمع.
              </Typography>
              <Typography variant="body1" paragraph>
                تأثرت بالعديد من المفكرين والفلاسفة والكتاب، وسعيت إلى تطوير رؤية خاصة تجمع بين العمق الفكري والتطبيق العملي.
              </Typography>
              <Typography variant="body1">
                أعتقد أن الفكر الحقيقي هو الذي يتجاوز النظريات المجردة إلى الممارسة اليومية، ويساهم في تحسين حياة الناس وتطوير المجتمعات.
              </Typography>
            </Paper>
          </Grid>
          
          {/* الرؤية */}
          <Grid item xs={12} md={6}>
            <Paper 
              elevation={2} 
              sx={{ 
                p: 3, 
                height: '100%',
                borderRadius: 2
              }}
            >
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <VisibilityIcon color="primary" sx={{ mr: 1 }} />
                <Typography variant="h5" component="h3">
                  {t('about.vision')}
                </Typography>
              </Box>
              <Divider sx={{ mb: 2 }} />
              <Typography variant="body1" paragraph>
                أسعى من خلال كتاباتي إلى المساهمة في بناء مجتمع أكثر وعياً وإنسانية، يقدر قيم العمل والإبداع والتعاون والمسؤولية.
              </Typography>
              <Typography variant="body1" paragraph>
                أؤمن بأن القيادة الحقيقية تبدأ من الداخل، وأن التغيير الإيجابي في المجتمع يبدأ من تغيير الأفراد لأنفسهم وطريقة تفكيرهم.
              </Typography>
              <Typography variant="body1">
                أطمح إلى تقديم محتوى فكري عميق وعملي في الوقت نفسه، يساعد القراء على فهم أنفسهم وعالمهم بشكل أفضل، واتخاذ قرارات أكثر حكمة وفعالية.
              </Typography>
            </Paper>
          </Grid>
          
          {/* الاهتمامات */}
          <Grid item xs={12} md={6}>
            <Paper 
              elevation={2} 
              sx={{ 
                p: 3, 
                height: '100%',
                borderRadius: 2
              }}
            >
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <InterestsIcon color="primary" sx={{ mr: 1 }} />
                <Typography variant="h5" component="h3">
                  {t('about.interests')}
                </Typography>
              </Box>
              <Divider sx={{ mb: 2 }} />
              <List>
                <ListItem>
                  <ListItemIcon>
                    <Box 
                      sx={{ 
                        width: 8, 
                        height: 8, 
                        borderRadius: '50%', 
                        backgroundColor: theme.palette.primary.main 
                      }} 
                    />
                  </ListItemIcon>
                  <ListItemText primary="القيادة وتطوير المؤسسات" />
                </ListItem>
                <ListItem>
                  <ListItemIcon>
                    <Box 
                      sx={{ 
                        width: 8, 
                        height: 8, 
                        borderRadius: '50%', 
                        backgroundColor: theme.palette.primary.main 
                      }} 
                    />
                  </ListItemIcon>
                  <ListItemText primary="ريادة الأعمال والابتكار" />
                </ListItem>
                <ListItem>
                  <ListItemIcon>
                    <Box 
                      sx={{ 
                        width: 8, 
                        height: 8, 
                        borderRadius: '50%', 
                        backgroundColor: theme.palette.primary.main 
                      }} 
                    />
                  </ListItemIcon>
                  <ListItemText primary="التطوير الذاتي وبناء العادات الإيجابية" />
                </ListItem>
                <ListItem>
                  <ListItemIcon>
                    <Box 
                      sx={{ 
                        width: 8, 
                        height: 8, 
                        borderRadius: '50%', 
                        backgroundColor: theme.palette.primary.main 
                      }} 
                    />
                  </ListItemIcon>
                  <ListItemText primary="الفلسفة وعلم النفس الإيجابي" />
                </ListItem>
                <ListItem>
                  <ListItemIcon>
                    <Box 
                      sx={{ 
                        width: 8, 
                        height: 8, 
                        borderRadius: '50%', 
                        backgroundColor: theme.palette.primary.main 
                      }} 
                    />
                  </ListItemIcon>
                  <ListItemText primary="القراءة والكتابة والتأمل" />
                </ListItem>
              </List>
            </Paper>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};

export default AboutPage;

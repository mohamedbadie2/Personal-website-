import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import ThemeWrapper from './components/ThemeWrapper';
import Header from './components/Header';
import HomePage from './components/HomePage';
import ArticlesPage from './components/ArticlesPage';
import BooksPage from './components/BooksPage';
import AboutPage from './components/AboutPage';
import ContactPage from './components/ContactPage';
import { Box, Container } from '@mui/material';
import './i18n/i18n';

function App() {
  return (
    <ThemeWrapper>
      <Router>
        <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
          <Header />
          <Box component="main" sx={{ flexGrow: 1 }}>
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/articles" element={<ArticlesPage />} />
              <Route path="/books" element={<BooksPage />} />
              <Route path="/about" element={<AboutPage />} />
              <Route path="/contact" element={<ContactPage />} />
            </Routes>
          </Box>
          <Box component="footer" sx={{ py: 3, bgcolor: 'background.paper', borderTop: 1, borderColor: 'divider' }}>
            <Container maxWidth="lg">
              <Box sx={{ textAlign: 'center', color: 'text.secondary' }}>
                © {new Date().getFullYear()} محمد عبدالبديع | تأملات في بناء الذات والواقع
              </Box>
            </Container>
          </Box>
        </Box>
      </Router>
    </ThemeWrapper>
  );
}

export default App;
